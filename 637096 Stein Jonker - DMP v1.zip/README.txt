Dit zip bestand bevat de eindproducten voor de minor DMP (Digital Media Productions)

De applicatie is toegankelijk op de url: https://infraviewer.steinjonker.nl/
Een account van de gemeente met Arcgis rechten is vereist.

De sourcecode is te vinden op Github (https://github.com/Staijn1/DMP) of in de infra-viewer map.
De map "built" bevat de gebouwde code die gebruikt kan worden om de website te hosten met IIS, apache of nginx.

De nginx.conf bevat de configuratie die gebruikt wordt voor de webserver, misschien dat delen hiervan als referentie gebruikt kunnen worden voor IIS.
Het belangrijkste onderdeel in deze configuratie is de
  location / {
      try_files $uri /index.html;
    }

Het zegt Nginx om te proberen om de opgevraagde URI (met de variabele $uri) als een fysiek bestand te vinden. 
Als dat niet lukt, gaat het naar /index.html.
Dit betekent dat wanneer een gebruiker een URL opvraagt die niet verwijst naar een bestaand fysiek bestand, Nginx de /index.html als de response geeft.
Dit is belangrijk want de ontwikkelde website is een single-page application en daarom wordt de afhandeling van pagina's in de browser gedaan en niet op de server.
De server staat hier standaard wel voor ingesteld. In IIS kun je vergelijkbare resultaten krijgen d.m.v. de "Rewrite Module"