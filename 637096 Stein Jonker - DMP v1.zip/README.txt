Dit zip bestand bevat de eindproducten voor de minor DMP (Digital Media Productions)

De applicatie is toegankelijk op de url: https://infraviewer.steinjonker.nl/
Een account van de gemeente met Arcgis rechten is vereist.

De sourcecode is te vinden op Github (https://github.com/Staijn1/DMP) of in de infra-viewer map.
