export type CustomError = {
  code: undefined | number;
  message: undefined | string;
};
