# NX Commands to know

Upgrading NX:

```bash
nx migrate next
```

Running migrations

```bash
nx migrate --run-migrations
```

# Building website

```bash
nx run website:build:production
```

# Building API

```bash
nx run api:build:production
```
