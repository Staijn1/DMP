export const environment = {
  production: true,
  api: "http://localhost:3333/api",
  hmr: true,
  portalURL: "https://geo.arnhem.nl/portal"
};
