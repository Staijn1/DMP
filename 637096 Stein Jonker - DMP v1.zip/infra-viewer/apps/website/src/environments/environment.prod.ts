export const environment = {
  production: true,
  api: "https://api.infraviewer.steinjonker.nl/api",
  hmr: false,
  portalURL: "https://geo.arnhem.nl/portal"
};
