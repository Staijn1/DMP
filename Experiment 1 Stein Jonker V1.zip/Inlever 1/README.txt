DRP.pdf 
	Design Research Paper
SRS.pdf 
	Software Requirements Specification, mijn deliverable voor de define fase.
	Hier worden de eisen in vastgesteld voor de applicatie

Experiment 1 Infraviewer.pdf
	In detail beschrijving van het uitgevoerde experiment. 
	De conclusie van het experiment is ook terug te lezen in het DRP

Map infraviewer
	Dit bevat de sourcecode van het expirement. Je kan dit niet direct openen.
	Het resultaat van het experiment is te zien op https://dmpexperiment1.netlify.app/
